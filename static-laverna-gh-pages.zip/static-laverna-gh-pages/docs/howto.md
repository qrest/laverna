### How to use tags in Laverna

When you are editing or creating notes, write "@" before any word to create a tag.

### How to use tasks in Laverna

You can create tasks by prefacing line with [ ] or [x] (incomplete or complete, respectively). Tasks will be automatically rendered as checkboxes that you can check on and off.
